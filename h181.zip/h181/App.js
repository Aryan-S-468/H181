import React, { Component } from "react";
import Main from './screens/main'

export default class App extends React.Component {
  render() {
    return(<Main/>)
  }
}